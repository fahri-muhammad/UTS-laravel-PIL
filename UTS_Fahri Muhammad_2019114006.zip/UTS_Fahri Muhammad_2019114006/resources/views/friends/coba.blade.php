@extends('layouts.app')

@section('title', 'cobacobacoba')

@section('content')
    Urutan ke - {{ $ke }}
@endsection