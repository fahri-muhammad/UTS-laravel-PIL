<?php $__env->startSection('title', 'Detail'); ?>

<?php $__env->startSection('content'); ?>
<div class="card border-success" style="max-width: 20rem;">
<div class="card-body text-secondary">

    <h5 style="color:black;">Nama Grup : <?php echo e($group['name']); ?></h5>
    <hr>
    <h5 style="color:black;">Description : <?php echo e($group['description']); ?></h5>



</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\UTS_Ridho Firmansyah_2019114015\resources\views/groups/show.blade.php ENDPATH**/ ?>