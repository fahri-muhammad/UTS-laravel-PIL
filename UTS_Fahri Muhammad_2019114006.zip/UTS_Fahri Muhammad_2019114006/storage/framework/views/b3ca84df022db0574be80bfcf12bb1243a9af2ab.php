<?php $__env->startSection('title', 'Friends'); ?>

<?php $__env->startSection('content'); ?>
<a href="/friends/create" class="btn btn-primary">Add Friends</a>
    <div class="row mt-3">
		<div class="col-md-6">

<?php $__currentLoopData = $friends; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $friend): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<div class="card border-success" style="width: 18rem;">
<div class="card-header">
<a href="/friends/<?php echo e($friend['id']); ?>" style="background-color: #ffffff"><?php echo e($friend['nama']); ?></a>
  </div>
    <div class="card-body">
        
        <ul class="list-group list-group-flush">
            <li class="list-group-item"><?php echo e($friend['no_telp']); ?></li>
            <li class="list-group-item"><?php echo e($friend['alamat']); ?></li>
            <li class="list-group-item"><?php echo e($friend['nama_grup']); ?> </li>
        </ul>
        <a href="/friends/<?php echo e($friend['id']); ?>/edit" class="btn btn-warning">Edit</a>
        <form action="/friends/<?php echo e($friend['id']); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>
        <button class="btn btn-danger">Delete</button>
        </form>
    </div>
</div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<div>
<div class="row mt-3">
		<div class="col-md-6">
<?php echo e($friends->links()); ?>

</div>
</div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\UTS_Ridho Firmansyah_2019114015\resources\views/friends/index.blade.php ENDPATH**/ ?>