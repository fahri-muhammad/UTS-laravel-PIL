<?php $__env->startSection('title', 'Detail'); ?>

<?php $__env->startSection('content'); ?>
<div class="card border-success" style="max-width: 20rem;">
<div class="card-body text-secondary">

    <h5 style="color:black;">Nama : <?php echo e($friend['nama']); ?></h5>
    <hr>
    <h5 style="color:black;">No. Telp : <?php echo e($friend['no_telp']); ?></h5>
    <hr>
    <h5 style="color:black;">Alamat : <?php echo e($friend['alamat']); ?></h5>
    <hr>
    <h5 style="color:black;">Grup : <?php echo e($friend['nama_grup']); ?></h5>

</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\UTS_Ridho Firmansyah_2019114015\resources\views/friends/show.blade.php ENDPATH**/ ?>